package com.hbp.pointdef;

import com.badlogic.gdx.math.Rectangle;

public class Kaboom {
	   Rectangle rect;
	   float birthtime;
}
